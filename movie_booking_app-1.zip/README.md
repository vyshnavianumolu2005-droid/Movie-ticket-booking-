# Movie Booking App

A beginner-friendly movie ticket booking prototype using HTML, CSS and JavaScript.

## How to run
1. Extract the ZIP.
2. Open `index.html` in Chrome.
3. Select movie, city, date, time and seats.
4. Enter your name.
5. Click Confirm Booking.

This is a frontend prototype. It does not include a real payment gateway or database.
